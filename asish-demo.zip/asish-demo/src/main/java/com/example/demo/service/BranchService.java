package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Branch;
import com.example.demo.repository.BranchRepository;

@Service
public class BranchService {

	@Autowired
	private BranchRepository repo;
	
	public Branch create(Branch branch) {
		return repo.save(branch);
	}
	public List<Branch> read() {
		return repo.findAll();
	}
	public Branch read(String bid) {
		return repo.findById(bid).get();
	}
	public Branch update(Branch branch) {
		return repo.save(branch);
	}
	public void delete(String bid) {
		repo.delete(read(bid));
	}
	
}
